from pydasrmt.Command.CmdGenerator import CmdGenerator
import pydasrmt.ProtoFile.CAN.Cmd_pb2 as CanCmd
import pydasrmt.ProtoFile.Sys.Cmd_pb2 as SysCmd


class CmdGeneratorCan(CmdGenerator):

    # def __init__(self):
        # super(CmdGeneratorCan,self).__init__()
        # pass

    def enableFlowCan(self, status):
        """set the client can recive data from server or not.(0x0004) 

        Args:
            status (bool): True/False

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = CanCmd.EnableDataFlowReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.Switch = status
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0004, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(request, 0x0004)

    def phyReadCan(self, frameId, name, frameStatus):
        """get the phy value of frame signal.(0x0005)

        Args:
            frameId (int): frame id.
            name (string): signal name.
            frameStatus (EFrameStatus): EFrameStatus.

        Returns:
            RecevicePhyValueResp: return an object of RecevicePhyValueResp.
        """
        req = CanCmd.RecevicePhyValueReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.ID = frameId
        req.Name = name
        req.FrameStatus = frameStatus
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0005, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(request, 0x0005)

    def sendCan(self, status, data, frameID=1):
        """send data by Can.(0x0008)

        Args:
            status (EFrameStatus): EFrameStatus.
            data (bytes): the data to be send.
            frameID (int, optional): frame id. Defaults to 1.
        """
        flow = CanCmd.Client2DasFlow()
        flow.Header.ParseFromString(self.getFlowHeader().SerializeToString())
        flow.Header.Data = data
        flow.ID= frameID
        flow.FrameStatus = status
        param = flow.SerializeToString()
        request = self.__Flow__(param, 0x0008, SysCmd.EPayloadProtocol.CAN)
        self.__SendMsg__(request)

    def setPhyValueCan(self, name, value, frameID=1):
        """set the PhyValue of the signal.(0x000C)

        Args:
            name (string): signal name.
            value (double): phy value.
            frameID (int, optional): frame id. Defaults to 1.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = CanCmd.UpdateAutoFramePhyValueReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.FrameID = frameID
        req.Name = name
        req.Value = value
        param = req.SerializeToString()
        request = self.__Req__(param, 0x000C, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(request, 0x000C)

    def setParamCan(self, interval, count, enable, frameID=1):
        """set the param of send data.(0x000D)

        Args:
            interval (int): time interval between each send.(ms)
            count (int): total count to be send.
            enable (int): 0-disable, 1-enable.
            frameID (int, optional): frame id. Defaults to 1.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = CanCmd.UpdateAutoFrameParameterReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.FrameID = frameID
        req.Interval = interval
        req.Count = count
        req.Enable = enable
        param = req.SerializeToString()
        request = self.__Req__(param, 0x000D, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(request, 0x000D)

    def enableStatisticCan(self, status):
        """set Statistic of Can enable/disable.(0x000E)

        Args:
            status (bool): True/False.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = CanCmd.StatisticsSwitchReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.Status = status        
        param = req.SerializeToString()
        request = self.__Req__(param, 0x000E, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(request, 0x000E)
    
    def getStatisticCan(self):
        """get Statistic of Can.(0x000F)

        Returns:
            StatisticsResp: StatisticsResp
        """
        req = self.__Req__(None, 0x000F, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(req, 0x000F)
    
    def reSetStatisticCan(self):
        """reset Statistic of Can.(0x0010)

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = self.__Req__(None, 0x0010, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(req, 0x0010)

    def listAutoFrame(self):
        """list the frames.(0x0011)

        Returns:
            ListAutoFrameResp: return an object of ListAutoFrameResp.
        """
        req = self.__Req__(None, 0x0011, SysCmd.EPayloadProtocol.CAN)
        return self.__SendMsgAndReciveResp__(req, 0x0011)

    def __GetRespType__(self, cmd):
        if (cmd == 0x3):
            return CanCmd.Das2ClientFlow()
        elif (cmd == 0x5):
            return CanCmd.RecevicePhyValueResp()
        elif (cmd == 0x8):
            return CanCmd.Client2DasFlow()
        elif (cmd == 0x0F):
            return CanCmd.StatisticsResp()
        elif (cmd == 0x11):
            return CanCmd.ListAutoFrameResp()
        else:
            return super().__GetRespType__(cmd)
