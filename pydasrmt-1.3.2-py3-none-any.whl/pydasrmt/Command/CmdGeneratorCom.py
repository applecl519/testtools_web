from pydasrmt.Command.CmdGenerator import CmdGenerator
import pydasrmt.ProtoFile.BasicStruct_pb2 as BS
import pydasrmt.ProtoFile.COM.Cmd_pb2 as ComCmd
import pydasrmt.ProtoFile.Sys.Cmd_pb2 as SysCmd


class CmdGeneratorCom(CmdGenerator):

    # def __init__(self):
    #     pass

    def enableFlowCom(self, status):
        """set the client can recive data from server or not.(0x0004) 

        Args:
            status (bool): True/False

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = ComCmd.EnableDataFlowReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.Switch = status
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0004, SysCmd.EPayloadProtocol.COM)
        return self.__SendMsgAndReciveResp__(request, 0x0004)

    def phyReadCom(self, frameId, name):
        """get the phy value of frame signal.(0x0005)

        Args:
            frameId (int): frame id.
            name (string): signal name.

        Returns:
            RecevicePhyValueResp: return an object of RecevicePhyValueResp.
        """
        req = ComCmd.RecevicePhyValueReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.ID = frameId
        req.Name = name
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0005, SysCmd.EPayloadProtocol.COM)
        return self.__SendMsgAndReciveResp__(request, 0x0005)

    def sendCom(self, data):
        """send data by Com.(0x0006)

        Args:
            data (bytes): the data to be send.
        """
        flow = BS.CommonFlow()
        flow.Header.ParseFromString(self.getFlowHeader().SerializeToString())
        flow.Header.Data = data
        param = flow.SerializeToString()
        request = self.__Flow__(param, 0x0006, SysCmd.EPayloadProtocol.COM)
        self.__SendMsg__(request)

    def setPhyValueCom(self, name, value, frameID=1):
        """set the PhyValue of the signal.(0x0007)

        Args:
            name (string): signal name.
            value (double): phy value.
            frameID (uint): signal's frameId.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = ComCmd.UpdateAutoFramePhyValueReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.FrameID = frameID
        req.Name = name
        req.Value = value
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0007, SysCmd.EPayloadProtocol.COM)
        return self.__SendMsgAndReciveResp__(request, 0x0007)

    def setParamCom(self, interval, count, enable, frameID=1):
        """set the param of send data.(0x0008)

        Args:
            interval (int): time interval between each send.(ms)
            count (int): total count to be send.
            enable (int): 0-disable, 1-enable.
            frameID (int, optional): frame id. Defaults to 1.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = ComCmd.UpdateAutoFrameParameterReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.FrameID = frameID
        req.Interval = interval
        req.Count = count
        req.Enable = enable
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0008, SysCmd.EPayloadProtocol.COM)
        return self.__SendMsgAndReciveResp__(request, 0x0008)

    def listAutoFrame(self):
        """list the frames.(0x0009)

        Returns:
            ListAutoFrameResp: return an object of ListAutoFrameResp.
        """
        req = self.__Req__(None, 0x0009, SysCmd.EPayloadProtocol.COM)
        return self.__SendMsgAndReciveResp__(req, 0x0009)

    def __GetRespType__(self, cmd):
        if (cmd == 0x0003):
            return ComCmd.Das2ClientFlow()
        if (cmd == 0x0005):
            return ComCmd.RecevicePhyValueResp()
        elif (cmd == 0x0009):
            return ComCmd.ListAutoFrameResp()
        else:
            return super().__GetRespType__(cmd)
