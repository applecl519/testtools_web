from pydasrmt.Command.CmdGenerator import CmdGenerator
import pydasrmt.ProtoFile.Sys.Cmd_pb2 as SysCmd
import pydasrmt.ProtoFile.SET.Cmd_pb2 as SetCmd


class CmdGeneratorSet(CmdGenerator):

    # def __init__(self):
    #     pass

    def readCards(self):
        """list all cards info.(0x0001)

        Returns:
            ReadBoxCardsResp: return all cards info.
        """
        req = self.__Req__(None, 0x0001, SysCmd.EPayloadProtocol.SET)
        return self.__SendMsgAndReciveResp__(req, 0x0001)

    def readCardsNode(self, cardType, cardIndex):
        """read card's node info.(0x0002)

        Args:
            cardType (ECardType): card type.
            cardIndex (int): card index.

        Returns:
            ReadCardNodeResp: return an object of ReadCardNodeResp.
        """
        req = SetCmd.ReadCardNodeReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.CardType = cardType
        req.CardIndex = cardIndex
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0002, SysCmd.EPayloadProtocol.SET)
        return self.__SendMsgAndReciveResp__(request, 0x0002)

    def setIO2Status(self, status, id):
        """set IO2 card's Status.(0x0003)

        Args:
            status (EIO2CardStatus): EIO2CardStatus.
            id (int): channel id.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = SetCmd.SetIO2Req()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.Status = status
        req.ChannelID = id
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0003, SysCmd.EPayloadProtocol.SET)
        self.__SendMsgAndReciveResp__(request, 0x0003)

    def setFIUStatus(self, status, id):
        """set FIU card's Status.(0x0004)

        Args:
            status (EFIUCardStatus): EFIUCardStatus.
            id (int): channel id.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = SetCmd.SetFIUReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.Status = status
        req.ChannelID = id
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0004, SysCmd.EPayloadProtocol.SET)
        self.__SendMsgAndReciveResp__(request, 0x0004)

    def __GetRespType__(self, cmd):
        if (cmd == 0x0001):
            return SetCmd.ReadBoxCardsResp()
        elif (cmd == 0x0002):
            return SetCmd.ReadCardNodeResp()
        else:
            return super().__GetRespType__(cmd)
