

class RemoteHeader(object):
    def __init__(self, data):
        self.System = 0
        self.Protocol = 0
        self.ChannelID = 0
        self.NodeID = 0
        self.PayloadType = 0
        self.CommandCode = 0
        if (len(data)>=7):
            self.System = data[0]
            self.Protocol = data[1]
            self.ChannelID = data[2]
            self.NodeID = data[3]
            self.PayloadType = data[4]
            self.CommandCode = data[6]<<8 | data[5]

