import zmq
import time


class ClientPS(object):
    """zmq client(Publish-Subscribe).

    Args:
        object (_type_): _description_

    Returns:
        _type_: _description_
    """
    flag_recivingMsg=False
    def __init__(self):
        """_summary_
        """
        pass

    # def initSocketSub(self):            
    #     """init a new subSocket.

    #     Returns:
    #         Socket: socketSub.
    #     """
    #     context = zmq.Context()
    #     socketSub = context.socket(zmq.SUB)  # type: zmq.Socket
    #     socketSub.connect ("tcp://%s:%d" % (self.ip, self.portSub))
    #     # 当zmq_setsockopt()的第二个参数设置为空时，表示不过滤任何消息
    #     socketSub.setsockopt(zmq.SUBSCRIBE, ''.encode('utf-8'))
    #     return socketSub

    def initSocketSub(self, filter=b''):            
        """init a new subSocket.

        Args:
            filter (bytes): socketSub.setsockopt

        Returns:
            Socket: socketSub
        """
        context = zmq.Context()
        socketSub = context.socket(zmq.SUB)  # type: zmq.Socket
        socketSub.connect ("tcp://%s:%d" % (self.ip, self.portSub))
        time.sleep(1)
        # 当zmq_setsockopt()的第二个参数设置为空时，表示不过滤任何消息
        socketSub.setsockopt(zmq.SUBSCRIBE, filter)
        return socketSub

    def setFilterOfSocketSub(self, filter=b''):            
        """set the filter of subSocket.

        Args:
            filter (bytes): socketSub.setsockopt
        """
        # 当zmq_setsockopt()的第二个参数设置为空时，表示不过滤任何消息
        self.socketSub.setsockopt(zmq.SUBSCRIBE, filter)

    def initSocketPub(self):
        context = zmq.Context()
        socketPub = context.socket(zmq.PUB)  # type: zmq.Socket
        socketPub.connect("tcp://%s:%d" % (self.ip, self.portPub))
        time.sleep(1)
        return socketPub

    def initSocket(self, ip="127.0.0.1", portPub=6667, portSub=6666):
        """initialize zmq socket.

        Args:
            ip (str, optional): ip address. Defaults to "127.0.0.1".
            portPub (int, optional): port for Publish Socket. Defaults to 6667.
            portSub (int, optional): port for Subscribe Socket. Defaults to 6666.
        """
        self.ip = ip
        self.portPub = portPub
        self.portSub = portSub
        self.socketPub = ClientPS.initSocketPub(self)
        self.socketSub = ClientPS.initSocketSub(self)

    def sendMsg(self, str):
        # if(self.socketPub is None):
        #     return
        self.socketPub.send(str)
        # time.sleep(1)

    def recvMsg(self):
        # socketSub = ClientPS.initSocketSub(self)
        resp = self.socketSub.recv()
        return resp

    def recvMsg(self, filter):
        socketSub = self.initSocketSub(filter)
        resp = socketSub.recv()
        return resp

