from base64 import encode
import pydasrmt.ProtoFile.BasicStruct_pb2 as BS
from pydasrmt.Command.ClientPS import *
import time
import func_timeout
import random


class CmdGenerator(object):
    """Cmd Generator.

    All commands are generated here Supported by VCarDAS.Remote2.

    Args:
        object (_type_): _description_
    """

    # channelNum = 2  # channel id
    # nodeNum = 1  # node id
    # client = ClientPS()  # zmq socket
    
    # TopicLength = 7  # the lengh of topic
    
    # SystemType = 1  # ESystem.System
    # PayloadType_Req = 1  # EPayloadDataType.Request
    # PayloadType_Resp = 2  # EPayloadDataType.Response
    # PayloadType_F2C = 3  # EPayloadDataType.Flow2Client
    # PayloadType_F2S = 4  # EPayloadDataType.Flow2Server

    def __init__(self):
        self.client = ClientPS()  # zmq socket
        
        self.channelNum = 2  # channel id
        self.nodeNum = 1  # node id
        self.SessionID = random.randint(10**4,10**9)  # RequestHeader/ResponseHeader SessionID
        self.TopicLength = 7  # the lengh of topic
        
        self.SystemType = 1  # ESystem.System
        self.PayloadType_Req = 1  # EPayloadDataType.Request
        self.PayloadType_Resp = 2  # EPayloadDataType.Response
        self.PayloadType_F2C = 3  # EPayloadDataType.Flow2Client
        self.PayloadType_F2S = 4  # EPayloadDataType.Flow2Server

    def getTime_ms(self):
        ms = int(time.time() * 1000)  # 1s = 1000ms
        return ms

    def getRandomInt(self, startInt=10**4, endInt=10**9):
        ranInt = random.randint(startInt, endInt)
        return ranInt

    def getReqHeader(self):
        header = BS.RequestHeader()
        header.SentUnixTimeStampMs = self.getTime_ms()
        header.SessionID = self.SessionID  # self.getRandomInt()
        return header

    def getFlowHeader(self):
        header = BS.FlowHeader()
        header.SentUnixTimeStampMs = self.getTime_ms()
        return header

    def __Req__(self, payload, cmd, protocol):
        """get the request message to be send.

        Args:
            payload (byte[]): CommonReq
            cmd (uint): command id
            protocol (EPayloadProtocol): EPayloadProtocol

        Returns:
            bytes: the request message to be send
        """

        if(payload is None):
            commonReq = BS.CommonReq()
            commonReq.Header.ParseFromString(self.getReqHeader().SerializeToString())
            payload = commonReq.SerializeToString()

        topic = bytes([self.SystemType, protocol, self.channelNum, self.nodeNum, self.PayloadType_Req, cmd & 0xff, cmd >> 8])
        return topic + payload

    def __Flow__(self, payload, cmd, protocol):
        """get the request message to be send.

        Args:
            payload (byte[]): CommonReq.
            cmd (uint): command id.
            protocol (EPayloadProtocol): EPayloadProtocol.

        Returns:
            bytes: the request message to be send.
        """

        topic = bytes([self.SystemType, protocol, self.channelNum, self.nodeNum, self.PayloadType_F2C, cmd & 0xff, cmd >> 8])
        return topic + payload

    def __GetRespType__(self, cmd):
        return BS.CommonResp()

    def __SendMsgAndReciveResp__(self, req, cmd):
        if (len(req)<7):
            return None
        reqTopic = req[:self.TopicLength]
        # filter:reqTopic[4] need change to 2(EPayloadDataType.Response)
        respTopic = reqTopic[:4] + bytes([self.PayloadType_Resp]) + reqTopic[5:]
        self.client.setFilterOfSocketSub(respTopic)
        # socketSub = self.client.initSocketSub(respTopic)
        # time.sleep(10)
        self.client.sendMsg(req)
        try:
            return self.__ReciveResp__(self.client.socketSub, cmd)
            # return self.__ReciveResp__(socketSub, cmd)
        except func_timeout.FunctionTimedOut:
            return None

    @func_timeout.func_set_timeout(30)
    def __ReciveResp__(self, socketSub, cmd):
        while True:
            resp = socketSub.recv()
            respObj = self.__GetRespType__(cmd)
            if (respObj is None):
                # print(f'[output]-----------------{resp}')
                return
            respObj.ParseFromString(resp[self.TopicLength:])
            if (respObj != None and respObj.Header.SessionID == self.SessionID):
                return respObj

    def __SendMsg__(self, req):
        self.client.sendMsg(req)
        # time.sleep(0.1)

    def initSocket(self, ip="127.0.0.1", portPub=6667, portSub=6666):
        self.client.initSocket(ip, portPub, portSub)

    def getSocketSub(self):
        return self.client.socketSub

    def setChannelNode(self, channelNum=0, nodeNum=1):
        self.channelNum = channelNum
        self.nodeNum = nodeNum

