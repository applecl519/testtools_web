from pydasrmt.Command.CmdGenerator import CmdGenerator
import pydasrmt.ProtoFile.UdsOnCan.Cmd_pb2 as UdsCmd
import pydasrmt.ProtoFile.Sys.Cmd_pb2 as SysCmd


class CmdGeneratorUdsOnCan(CmdGenerator):

    # def __init__(self):
    #     pass

    def createTester(self):
        """create a Tester.(0x0001)

        Returns:
            CreateTesterResp: CreateTesterResp.
        """
        request = self.__Req__(None, 0x0001, SysCmd.EPayloadProtocol.UdsOnCan)
        return self.__SendMsgAndReciveResp__(request, 0x0001)

    def DisposeTester(self, uid):
        """Dispose Tester.(0x0002)

        Args:
            uid (int): the uid of Tester.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = UdsCmd.DisposeTesterReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.UID = uid
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0002, SysCmd.EPayloadProtocol.UdsOnCan)
        self.__SendMsgAndReciveResp__(request, 0x0002)

    def configTester(self, uid, txId, rxId, isExtended=False, isCanfd=False,
                    isBrs=False, isPadding=False, padValue=False):
        """set the config of Tester.(0x0003)

        Args:
            uid (int): uid.
            txId (int): txId.
            rxId (int): rxId.
            isExtended (bool, optional): isExtended. Defaults to False.
            isCanfd (bool, optional): isCanfd. Defaults to False.
            isBrs (bool, optional): isBrs. Defaults to False.
            isPadding (bool, optional): isPadding. Defaults to False.
            padValue (bool, optional): padValue. Defaults to False.

        Returns:
            CommonResp: return an object of CommonResp.
        """
        req = UdsCmd.ConfigTesterReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.UID = uid
        req.TxId = txId
        req.RxId = rxId
        req.IsExtended = isExtended
        req.IsCanfd = isCanfd
        req.IsBrs = isBrs
        req.IsPadding = isPadding
        req.PadValue = padValue
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0003, SysCmd.EPayloadProtocol.UdsOnCan)
        self.__SendMsgAndReciveResp__(request, 0x0003)

    def sendUdsCommand(self, uid, command):
        """send Uds Command.(0x0004)

        Args:
            uid (int): the uid of Tester.
            command (bytes): uds command

        Returns:
            SendUdsCommandResp: SendUdsCommandResp
        """
        req = UdsCmd.SendUdsCommandReq()
        req.Header.ParseFromString(self.getReqHeader().SerializeToString())
        req.UID = uid
        req.Data = command
        param = req.SerializeToString()
        request = self.__Req__(param, 0x0004, SysCmd.EPayloadProtocol.UdsOnCan)
        return self.__SendMsgAndReciveResp__(request, 0x0004)

    def __GetRespType__(self, cmd):
        if (cmd == 0x01):
            return UdsCmd.CreateTesterResp()
        elif (cmd == 0x04):
            return UdsCmd.SendUdsCommandResp()
        else:
            return super().__GetRespType__(cmd)
