from pydasrmt.Command.CmdGenerator import CmdGenerator
import pydasrmt.ProtoFile.Sys.Cmd_pb2 as SysCmd


class CmdGeneratorSys(CmdGenerator):

    # def __init__(self):
    #     pass

    def listService(self):
        """list the services surpoted.(0x0001)

        Returns:
            AvailableServiceResp: return an object of AvailableServiceResp.
        """
        req = self.__Req__(None, 0x0001, SysCmd.EPayloadProtocol.System)
        return self.__SendMsgAndReciveResp__(req, 0x0001)

    def switch(self, status):
        """set the global switch on/off.(0x0002)

        Args:
            status (bool): True/False.

        Returns:
            GlobalSwitchResp: return an object of GlobalSwitchResp.
        """
        reqSwitch = SysCmd.GlobalSwitchReq()
        reqSwitch.Header.ParseFromString(self.getReqHeader().SerializeToString())
        reqSwitch.SwitchStatus = status
        param = reqSwitch.SerializeToString()
        req = self.__Req__(param, 0x0002, SysCmd.EPayloadProtocol.System)
        return self.__SendMsgAndReciveResp__(req, 0x0002)

    def __GetRespType__(self, cmd):
        if (cmd == 0x01):
            return SysCmd.AvailableServiceResp()
        elif (cmd == 0x02):
            return SysCmd.GlobalSwitchResp()
